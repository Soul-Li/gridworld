import info.gridworld.actor.ActorWorld;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.actor.Critter;
import info.gridworld.grid.Location;

public class BlusterRunner {
    public static void main(String[] args) {
        ActorWorld world = new ActorWorld();
        int num = 50;
        for (int i = 0; i < num; i++) {
            world.add(new Critter());
        }
        world.add(new BlusterCritter(15));
        world.show();
    }
}
