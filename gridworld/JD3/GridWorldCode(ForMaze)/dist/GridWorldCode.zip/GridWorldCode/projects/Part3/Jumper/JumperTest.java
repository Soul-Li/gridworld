import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class JumperTest {
    
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testMove() {
		
		//fail("Not yet implemented");
	}

	@Test
	public void testCanMove() {
		//fail("Not yet implemented");
	}

}
